Place tes certificats SSL ici :
- fullchain.pem (certificat)
- privkey.pem (clé privée)

Génération avec Certbot (Let's Encrypt) :
  certbot certonly --standalone -d ton-domaine.com
